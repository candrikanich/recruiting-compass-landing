
  # TRC Landing Page Concept

  This is a code bundle for TRC Landing Page Concept. The original project is available at https://www.figma.com/design/EvKsevaabTQ4TkMnZjlwTn/TRC-Landing-Page-Concept.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  